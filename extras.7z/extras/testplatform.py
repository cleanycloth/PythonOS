from colorama import init
init()
from colorama import Fore
