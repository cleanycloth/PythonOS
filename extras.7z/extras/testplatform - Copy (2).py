from random import randint
from time import sleep
friendhealth = 20
enemyhealth = 20
from os import system
while 1:
    x = randint(1,10)
    if x == 1 or x == 2:
        print("You missed!")
    elif x == 3 or x == 4 or x == 10:
        print("The enemy missed!")
    elif x == 5 or x == 6 or x == 7:
        print("HIT! - Player to Enemy")
        enemyhealth = enemyhealth - 1
    elif x == 8 or x == 9:
        print("HIT! - Enemy to Player")
        friendhealth = friendhealth - 1
    print("Friendly health:",friendhealth)
    print("Enemy health:",enemyhealth)
    sleep(0.1)
    system('cls')
    if friendhealth == 0:
        print("GAME OVER - YOU DIED")
        break
    elif enemyhealth == 0:
        print("GAME OVER - YOU WIN")
        break
