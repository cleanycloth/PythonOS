#!/usr/bin/python
from time import sleep
from os import path, system
rand = 0
sc = 0
def animation():
    print("(=        )".rjust(45), end='\r'), sleep(0.07)
    print("(==       )".rjust(45), end='\r'), sleep(0.07)
    print("(===      )".rjust(45), end='\r'), sleep(0.07)
    print("( ===     )".rjust(45), end='\r'), sleep(0.07)
    print("(  ===    )".rjust(45), end='\r'), sleep(0.07)
    print("(   ===   )".rjust(45), end='\r'), sleep(0.07)
    print("(    ===  )".rjust(45), end='\r'), sleep(0.07)
    print("(     === )".rjust(45), end='\r'), sleep(0.07)
    print("(      ===)".rjust(45), end='\r'), sleep(0.07)
    print("(       ==)".rjust(45), end='\r'), sleep(0.07)
    print("(        =)".rjust(45), end='\r'), sleep(0.07)
    print("(         )".rjust(45), end='\r'), sleep(0.5)
    print("".rjust(49), end='\r')
def wintitle():
    system('title PythonOS Virtual Machine - Version 0.5 (C) RotoWare 2015')
wintitle()
def logo():
    print("    ____        __  __                ____  _____"), sleep(0.05)
    print("   / __ \__  __/ /_/ /_  ____  ____  / __ \/ ___/"), sleep(0.05)
    print("  / /_/ / / / / __/ __ \/ __ \/ __ \/ / / /\__ \ "), sleep(0.05)
    print(" / ____/ /_/ / /_/ / / / /_/ / / / / /_/ /___/ / "), sleep(0.05)
    print("/_/    \__  /\__/_/ /_/\____/_/ /_/\____//____/  "), sleep(0.05)
    print("      /____/                                     "), sleep(0.2)
def screenclear():
    system('cls')
    if sc == 1:
        print("PythonOS 0.5 Alpha - Do not distribute!".rjust(79))
def crash():
    system('color 1f')
    if rand == 27:
        print("*** STOP: 0x0000007F (0xC107C534, 0x00000000, 0x804F5830, 0x00000000)"), sleep(0.01)
        print("UNEXPECTED_KERNEL_MODE_TRAP"), sleep(0.01)
    else:
        print("*** STOP: 0xDEADDEAD (0xC107C534, 0x00000000, 0x804F5830, 0x00000000)"), sleep(0.01)
        print("MANUALLY_INITIATED_CRASH1"), sleep(0.01)
    print("\n*** Address 804F5380 base at 80400000, Datestamp 45ec3c8f - ntoskrnl.exe"), sleep(0.01)
    print("\nIf this is the first time you've seen this stop error screen,"), sleep(0.01)
    print("restart your computer. If this screen appears again, follow"), sleep(0.01)
    print("these steps:"), sleep(0.01)
    print("\nCheck to make sure any new hardware or software is properly installed."), sleep(0.01)
    print("If this is a new installation, ask your hardware or software manufacturer"), sleep(0.01)
    print("for any PythonOS updates you might need."), sleep(0.01)
    print("\nIf problems continue, disable or remove any newly installed hardware"), sleep(0.01)
    print("or software. Disable BIOS memory options such as caching or shadowing."), sleep(0.01)
    print("If you need to use Safe Mode to remove or disable components, restart"), sleep(0.01)
    print("your computer, press F8 to select Advanced Startup Options, and then"), sleep(0.01)
    print("select safemode."), sleep(0.01)
    print("\nRefer to your Getting Started manual for more information on"), sleep(0.01)
    print("troubleshooting Stop errors.\n"), sleep(0.01)
    sleep(1)
    for x in range(1,101):
        print("Preparing dump of physical memory... (" + str(x) + "%)", end='\r'), sleep(0.05)
    print("\nPhysical memory dump complete."), sleep(0.5)
    print("Contact your system administrator for more information on this STOP error."), sleep(4)
    print("Attempting to restart PythonOS."), sleep(1)
    exit()
screenclear()
system('color 07')
sleep(0.5)
print("PhoenixBIOS 4.0 Release 6.0"), sleep(0.05)
print("Copyright 1985-2001 Phoenix Technologies Ltd."), sleep(0.05)
print("All Rights Reserved"), sleep(0.05)
print("Copyright 2015 RotoWare"), sleep(0.05)
print("PythonBIOS build 022\n"), sleep(0.5)
print("640K System RAM Passed"), sleep(0.3)
for a in range(1,129):
    print(str(a) + "M Extended RAM Passed", end='\r'), sleep(0.02)
print(""), sleep(1)
print("Scanning IDE channels for devices...", end='\r'), sleep(2)
print("Fixed Disk 0: RotoWare IDE Virtual Hard Drive"), sleep(0.1)
print("ATAPI CD-ROM: Not found"), sleep(0.1)
print("Keyboard initialized")
print("\nLoading modules...", end='\r')
from random import randint
from getpass import getpass
from time import asctime
from os import remove, chdir
from platform import platform
from sys import exit as ex
from platform import system as syst
sleep(0.5)
print("Loading modules completed successfully.")
print("\n\n\n\n\n\n\n\nPress F2 to enter SETUP, F12 for Network Boot, ESC for Boot menu"), sleep(2)
screenclear()
sleep(2)
print("PythonOS 0.5 Alpha - Do not distribute!".rjust(79))
print("\n\n\n\n\n\n"), sleep(0.1)
print("╔═══════════════════════════════════╗".rjust(59)), sleep(0.1)
print("║Starting PythonOS Developer Preview║".rjust(59)), sleep(0.1)
print("╚═══════════════════════════════════╝".rjust(59)), sleep(0.5)
print("\n\n\n\n\n\n\n")
print("(         )".rjust(45), end='\r'), sleep(0.5)
randstart = randint(4,9)
for x in range(randstart):
    animation()
if not path.exists("safeshutdown.txt"):
    file = open('safeshutdown.txt', "w")
    file.close()
if not path.exists("s.txt"):
    file = open('s.txt', "w")
    file.close()
if not "1" in open("safeshutdown.txt").read():
    screenclear()
    system('py.exe "scandisk.py"')
    sleep(2)
    file4 = open('safeshutdown.txt', "w")
    file4.write("1"), file4.close()
    sleep(0.2)
    ex()
sleep(0.5)
rand = randint(1,50)
sc = 1
file = open('safeshutdown.txt', "w")
file.write("0"), file.close()
file4 = open('s.txt', "w")
file4.write("0"), file4.close()
screenclear()
sleep(1)
if rand == 27:
    sc = 0
    crash()
print("Welcome, to..."), sleep(0.2)
logo()
print("\nVersion 0.5 Pre-Alpha - Copyright RotoWare 2015"), sleep(2)
print("\nBuild Date: 03/12/15 @ 11:50"), sleep(0.5)
print("\nThe time is", asctime(), "\n"), sleep(0.5)
if not path.exists("programlist.txt"):
    file = open('programlist.txt', "w")
    file.close()
while 1:
    wintitle()
    sleep(0.2)
    main = input("root@PythonOS-Test> ")
    if main == "list commands":
        print("list commands, help, help edit, edit, ver, logo, list programs,\nls/dir, magic 8 ball, clear/cls, apt-get install,\nopen, shutdown/exit, manucrash, reboot/restart")
    if main == "help":
        chdir('Documents')
        system('k.exe pythonoshelp.txt')
        chdir('..')
    if main == "help edit":
        chdir('Documents')
        system('k.exe khelp.txt')
        chdir('..')
        main = ""
    if "edit" in main:
        chdir('Documents')
        main = main.replace("edit", "")
        system('k.exe' + main)
        chdir('..')
    if main == "ver":
        print("PythonOS Version 0.5 Pre-Alpha")
    if main == "logo":
        logo()
    if main == "list programs":
        system('type programlist.txt')
        print("\n")
    if main == "ls" or main == "dir":
        print("magic 8 ball")
    if main == "magic 8 ball":
        system('py.exe string.Input.Magic8Ball5.py')
    if main == "clear" or main == "cls":
        screenclear()
    if "apt-get install" in main:
        main = main.replace("apt-get install ", "")
        for x in range(1,101):
            print("Checking repositories...(" + str(x) + "%)", end='\r')
            sleep(0.02)
        print("")
        x = 0
        rand1 = randint(0,20)
        for x in range(1,101):
            print("Downloading", main, "from http:\\repositories.pythonos.net... (" + str(x) + "%)", end='\r')
            sleep(rand1/100)
        file3 = open('programlist.txt', "a")
        file3.write(main), file3.write(", "), file3.close()  
        print("\nExtracting and setting up", main, end='\r')
        if rand1 < 10:
            sleep(rand1)
        else:
            sleep(rand1/10)
        print("Extracting and setting up", main,"complete.")
    if "open" in main:
        main = main.replace("open ", "")
        if main in open("programlist.txt").read():
            print("Starting", main + ".")
            system("start " + main)
        if not main in open("programlist.txt").read():
            print("Program not installed. Run apt-get to install it.")
    if main == "shutdown" or main == "exit":
        print("\nBroadcast from root@PythonOS-Test (pts/0) (" + asctime() + ")")
        print("\nThe system is going down NOW!")
        sleep(3)
        print("\nPowering off...")
        file4 = open('safeshutdown.txt', "w")
        file4.write("1"), file4.close()
        file4 = open('s.txt', "w")
        file4.write("1"), file4.close()
        sleep(0.2)
        ex()
    if "manucrash" in main:
        sc = 0
        screenclear()
        crash()
    if main == "reboot" or main == "restart":
        print("\nBroadcast from root@PythonOS-Test (pts/0) (" + asctime() + ")")
        print("\nThe system is going down for reboot NOW!")
        sleep(3)
        print("\nRestarting...")
        file4 = open('safeshutdown.txt', "w")
        file4.write("1"), file4.close()
        sleep(0.2)
        ex()
print("Uh oh, you shouldn't see me. If you can, something is really badly wrong.")
print("Inspection of the code is required. System halted.")
system("pause >nul")
exit()
