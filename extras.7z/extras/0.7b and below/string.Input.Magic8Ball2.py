#The Magic 8 Ball, programmed by Aidan Rayner with optimization and some extra features by Nathan Barrall.
from random import choice
from time import sleep, asctime
from sys import exit, getwindowsversion
from os import path, remove
print("                                                            Magic 8 Ball v2.3")
print()
if not path.exists("m8ballresults.txt"):
    print("Generating new results file...")
    file = open('m8ballresults.txt', "w")
    file.close()
if not path.exists("m8ballusernames.txt"):
    print("Generating new usernames file...")
    print()
    file2 = open('m8ballusernames.txt', "w")
    file2.close()
print("Hello, and welcome to the Magic 8 Ball application. My name is Dave.")
a = input("What is your name? ")
if a == "%debug%":
    print("Welcome to the Magic 8 Ball debug mode.")
    debug1 = input("What would you like to do?\n1. Delete m8ballresults.txt file\n2. Delete m8ballusernames.txt file\n3. Delete both files\n")
    if debug1 == "1":
        if path.exists("m8ballresults.txt"):
            print("Deleting file...")
            remove("m8ballresults.txt")
            print("File deleted.")
            exit()
        if not path.exists("m8ballresults.txt"):
            print("File not found. Please restart.")
            exit()
    if debug1 == "2":
        if path.exists("m8ballusernames.txt"):
            print("Deleting file...")
            remove("m8ballusernames.txt")
            print("File deleted.")
            exit()
        if not path.exists("m8ballusernames.txt"):
            print("File not found. Please restart.")
            exit()
    if debug1 == "3":
        print("This has not been implemented yet. Sorry!")
        exit()
if a in open('m8ballusernames.txt').read():
    print("Welcome back. I see you seek more advice.")
else:
    qu = input("Welcome, new user. \nYour name, question, and answer will be saved to a file in plaintext. \nDo you accept? [y/n] ")
    if qu == "y":
        file3 = open('m8ballusernames.txt', "w")
        file3.write(a) & file3.write("\n")
        file3.close()
        print("Thank you. Your username has been saved.")
    else:
        print("You have not accepted the EULA. Closing the application.")
        exit()
        sleep(3)
print()
b = input("Ask me a question! Any question; I don't mind. : ")
if b == "What's the time?":
    print("The time and date is", asctime())
    sleep(5)
    exit()
if b == "What version of Windows am I running?":
    print("You are running", getwindowsversion())
    sleep(5)
    exit()
for x in range(1,5):
    print("Shaking... "+str(x)+"/4")
    sleep(0.25)
print()
c = choice([
    "Try again later.",
    "Most certainly.",
    "The answer is something I cannot comprehend.",
    "java.lang.DoItLaterException(): Can't be bothered right now.",
    "No.",
    "Are you serious? No!",
    "Erm...okay. Sure.",
    "Yes.",
    "I don't know...",
    "Ask Neil, he might know.",
    "Something tells me that you shouldn't be asking me this...",
    "Quite possibly, though I cannot make any promises.",
    "Nah.",
    "Yeah!",
    "I fear the NSA is watching, so I won't answer this.",
    "Haha, no.",
    "Hm, maybe.",
    "Okay, yeah. Why not?",
    "Google is your friend.",
    "Don't tell Neil or Astrobot_, I don't want to give them any ideas!",
])
print("The Magic 8 Ball says:", c)
game = open("m8ballresults.txt", "a")
game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(c) & game.write("\n") & game.write("\n")
game.close()
print()
print("Your data has been saved to m8ballresults.txt")
sleep(3)
