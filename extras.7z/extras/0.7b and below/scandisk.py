from os import system
from time import sleep
system('color 1f'), sleep(0.05)
print("\n\n    RotoWare Scandisk"), sleep(0.05)
print("    ----------------------------------------------------------------------"), sleep(0.05)
print("\n    Because PythonOS was not properly shut down,"), sleep(0.05)
print("    one or more of your disk drives may have errors on it."), sleep(0.05)
print("\n    To avoid seeing this message again, always shut down"), sleep(0.05)
print("    your computer by typing \"exit\" or \"shutdown\""), sleep(0.05)
print("    at the command line."), sleep(0.05)
print("\n    Scandisk is now checking drive C for errors:"), sleep(0.05)
print("\n\n\n\n\n\n\n")
print("    ----------------------------------------------------------------------"), sleep(0.5)
print("    " + "0" + "% complete       (                                                  )", end='\r'), sleep(1.5)
for x in range(1,3):
    print("    " + str(x) + "% complete       (=                                                 )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+2) + "% complete       (==                                                )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+4) + "% complete       (===                                               )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+6) + "% complete       (====                                              )", end='\r'), sleep(0.1)
print("    " + str(9) + "% complete       (=====                                             )", end='\r'), sleep(0.1)
print("    " + str(10) + "% complete      (======                                            )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+10) + "% complete      (======                                            )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+12) + "% complete      (=======                                           )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+14) + "% complete      (========                                          )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+16) + "% complete      (=========                                         )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+18) + "% complete      (==========                                        )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+20) + "% complete      (===========                                       )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+22) + "% complete      (============                                      )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+24) + "% complete      (=============                                     )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+26) + "% complete      (==============                                    )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+28) + "% complete      (===============                                   )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+30) + "% complete      (================                                  )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+32) + "% complete      (=================                                 )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+34) + "% complete      (==================                                )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+36) + "% complete      (===================                               )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+38) + "% complete      (====================                              )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+40) + "% complete      (=====================                             )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+42) + "% complete      (======================                            )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+44) + "% complete      (=======================                           )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+46) + "% complete      (========================                          )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+48) + "% complete      (=========================                         )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+50) + "% complete      (==========================                        )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+52) + "% complete      (===========================                       )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+54) + "% complete      (============================                      )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+56) + "% complete      (=============================                     )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+58) + "% complete      (==============================                    )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+60) + "% complete      (===============================                   )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+62) + "% complete      (================================                  )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+64) + "% complete      (=================================                 )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+66) + "% complete      (==================================                )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+68) + "% complete      (===================================               )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+70) + "% complete      (====================================              )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+72) + "% complete      (=====================================             )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+74) + "% complete      (======================================            )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+76) + "% complete      (=======================================           )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+78) + "% complete      (========================================          )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+80) + "% complete      (=========================================         )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+82) + "% complete      (==========================================        )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+84) + "% complete      (===========================================       )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+86) + "% complete      (============================================      )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+88) + "% complete      (=============================================     )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+90) + "% complete      (==============================================    )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+92) + "% complete      (===============================================   )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+94) + "% complete      (================================================  )", end='\r'), sleep(0.1)
for x in range(1,3):
    print("    " + str(x+96) + "% complete      (================================================= )", end='\r'), sleep(0.1)
print("    " + str(99) + "% complete      (==================================================)", end='\r'), sleep(0.1)
print("    " + str(100) + "% complete     (==================================================)", end='\r'), sleep(0.1)
sleep(2)
system('cls')
print("\n\n    RotoWare Scandisk"), sleep(0.05)
print("    ----------------------------------------------------------------------"), sleep(0.05)
print("\n    Drive C: scanned sucessfully. No errors found."), sleep(0.05)
print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n"), sleep(0.05)
print("    ----------------------------------------------------------------------"), sleep(2)
