from os import system
from time import sleep
while 1:
    go = system('py.exe "PythonOS0.5.py"')
    if go == 2:
        print("\nCan't start the VM. You are most likely trying to start from a network drive,\nwhich is unsupported in Windows. Try running the VM again from a local drive.")
        sleep(400)
    if "1" in open("s.txt").read():
        exit()
 
