from os import system, path
if not path.exists("s.txt"):
    file = open('s.txt', "w")
    file.close()

file = open('s.txt', "w")
while 1:
    file.write("1")
