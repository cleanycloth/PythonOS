#!/usr/bin/python
#Load modules and set variables required for defined functions:
from time import sleep
from os import path, system
rand = 0
sc = 0

#Define necessary functions:
def writefiles(file, number):
    file = open(file, "w")
    file.write(number), file.close()
def workdir():
    global owd1
    owd1 = getcwd()
    chdir(owd)
def startlogo():
    print("PythonOS 0.7 Alpha - Do not distribute!".rjust(79))
    print("\n\n\n\n\n\n"), sleep(0.1)
    print("╔═══════════════════════════════════╗".rjust(59)), sleep(0.1)
    print("║Starting PythonOS Developer Preview║".rjust(59)), sleep(0.1)
    print("╚═══════════════════════════════════╝".rjust(59)), sleep(0.5)
    print("\n\n\n\n\n\n\n")
    print("(         )".rjust(45), end='\r'), sleep(0.5)    
def animation():
    print("(=        )".rjust(45), end='\r'), sleep(0.07)
    print("(==       )".rjust(45), end='\r'), sleep(0.07)
    print("(===      )".rjust(45), end='\r'), sleep(0.07)
    print("( ===     )".rjust(45), end='\r'), sleep(0.07)
    print("(  ===    )".rjust(45), end='\r'), sleep(0.07)
    print("(   ===   )".rjust(45), end='\r'), sleep(0.07)
    print("(    ===  )".rjust(45), end='\r'), sleep(0.07)
    print("(     === )".rjust(45), end='\r'), sleep(0.07)
    print("(      ===)".rjust(45), end='\r'), sleep(0.07)
    print("(       ==)".rjust(45), end='\r'), sleep(0.07)
    print("(        =)".rjust(45), end='\r'), sleep(0.07)
    print("(         )".rjust(45), end='\r'), sleep(0.5)
    print("".rjust(49), end='\r')
def wintitle():
    system('title PythonOS Virtual Machine - Version 0.7 (C) RotoWare 2015') # This sets the command line window title.
wintitle()
def logo():
    print("    ____        __  __                ____  _____"), sleep(0.05)
    print("   / __ \__  __/ /_/ /_  ____  ____  / __ \/ ___/"), sleep(0.05)
    print("  / /_/ / / / / __/ __ \/ __ \/ __ \/ / / /\__ \ "), sleep(0.05)
    print(" / ____/ /_/ / /_/ / / / /_/ / / / / /_/ /___/ / "), sleep(0.05)
    print("/_/    \__  /\__/_/ /_/\____/_/ /_/\____//____/  "), sleep(0.05)
    print("      /____/                                     "), sleep(0.2)
def screenclear():
    system('cls')
    if sc == 1:
        print("PythonOS 0.7 Alpha - Do not distribute!".rjust(79))
def crash():
    system('color 1f')
    if rand == 27:
        print("*** STOP: 0x0000007F (0xC107C534, 0x00000000, 0x804F5830, 0x00000000)"),     sleep(0.01)
        print("UNEXPECTED_KERNEL_MODE_TRAP"),                                               sleep(0.01)
    else:
        print("*** STOP: 0xDEADDEAD (0xC107C534, 0x00000000, 0x804F5830, 0x00000000)"),     sleep(0.01)
        print("MANUALLY_INITIATED_CRASH1"),                                                 sleep(0.01)
    print("\n*** Address 804F5380 base at 80400000, Datestamp 45ec3c8f - ntoskrnl.exe"),    sleep(0.01)
    print("\nIf this is the first time you've seen this stop error screen,"),               sleep(0.01)
    print("restart your computer. If this screen appears again, follow"),                   sleep(0.01)
    print("these steps:"),                                                                  sleep(0.01)
    print("\nCheck to make sure any new hardware or software is properly installed."),      sleep(0.01)
    print("If this is a new installation, ask your hardware or software manufacturer"),     sleep(0.01)
    print("for any PythonOS updates you might need."),                                      sleep(0.01)
    print("\nIf problems continue, disable or remove any newly installed hardware"),        sleep(0.01)
    print("or software. Disable BIOS memory options such as caching or shadowing."),        sleep(0.01)
    print("If you need to use Safe Mode to remove or disable components, restart"),         sleep(0.01)
    print("your computer, press F8 to select Advanced Startup Options, and then"),          sleep(0.01)
    print("select safemode."),                                                              sleep(0.01)
    print("\nRefer to your Getting Started manual for more information on"),                sleep(0.01)
    print("troubleshooting Stop errors.\n"),                                                sleep(0.01)
    sleep(1)
    for x in range(1,101):
        print("Preparing dump of physical memory... (" + str(x) + "%)", end='\r'),          sleep(0.05)
    print("\nPhysical memory dump complete."),                                              sleep(0.5)
    print("Contact your system administrator for more information on this STOP error."),    sleep(4)
    print("Attempting to restart PythonOS."),                                               sleep(1)
    ex()
#Main runtime code starts here
screenclear()
system('color 07')
sleep(0.5)
print("PhoenixBIOS 4.0 Release 6.0"), sleep(0.05)
print("Copyright 1985-2001 Phoenix Technologies Ltd."), sleep(0.05)
print("All Rights Reserved"), sleep(0.05)
print("Copyright 2015 RotoWare"), sleep(0.05)
print("PythonBIOS build 022\n"), sleep(0.5)
print("640K System RAM Passed"), sleep(0.3)
for a in range(1,129):
    print(str(a) + "M Extended RAM Passed", end='\r'), sleep(0.02)
print(""), sleep(1)
print("Scanning IDE channels for devices...", end='\r'), sleep(2)
print("Fixed Disk 0: RotoWare IDE Virtual Hard Drive"), sleep(0.1)
print("ATAPI CD-ROM: Not found"), sleep(0.1)
print("Keyboard initialized")
print("\nLoading modules...", end='\r')
from msvcrt import getch
from random import randint
from getpass import getpass
from time import asctime
from os import remove, chdir, getcwd
from platform import platform
from sys import exit as ex
owd = getcwd()
sleep(1)
print("Loading modules completed successfully.")
print("\n\n\n\n\n\n\n\n")
print("Press F2 to enter SETUP, F12 for Network Boot, ESC for Boot menu"), sleep(2)
screenclear()
sleep(2)
startlogo()

#Checks for files missing, and stops the OS from loading if any are.
if not path.exists("Documents/k.exe") or not path.exists("Documents/string.input.magic8ball5.py") or not path.exists("Documents/khelp.txt") or not path.exists("Documents/pythonoshelp.txt") or not path.exists("scandisk.py"):
    sleep(1)
    screenclear()
    print("PythonOS cannot continue loading because the following files are missing:")
    if not path.exists("Documents/k.exe"):
        print("/Documents/k.exe")
    if not path.exists("string.Input.magic8ball5.py"):
        print("/Documents/string.Input.magic8ball5.py")
    if not path.exists("Documents/khelp.txt"):
        print("/Documents/khelp.txt")
    if not path.exists("Documents/pythonoshelp.txt"):
        print("/Documents/pythonoshelp.txt")
    if not path.exists("scandisk.py"):
        print("/scandisk.py")
    print("Replace these files, and press any key to restart.")
    getch()
    ex()

randstart = randint(4,7)
if not path.exists("safeshutdown.txt"):
    writefiles("safeshutdown.txt","0")
if not path.exists("programlist.txt"):
    writefiles("programlist.txt","")
writefiles("s.txt","0")
writefiles("m8ballresults.txt","")
writefiles("m8ballusernames.txt","")
##for x in range(randstart):
##    if not "1" in open("safeshutdown.txt").read():
##        animation(), animation()
##        screenclear()
##        system('py.exe "scandisk.py"')                            ###please uncomment###
##        sleep(2)
##        writefiles("safeshutdown.txt","1")
##        sleep(0.2)
##        system('color 07')
##        system('cls')
##        startlogo()
##    animation()
writefiles("safeshutdown.txt","1")    ###please change back to 0###
sleep(0.5)
rand = randint(1,50)
sc = 1
screenclear()
sleep(1)
if rand == 27:
    sc = 0
    screenclear()
    crash()
print("Welcome, to..."), sleep(0.2)
logo()
print("\nVersion 0.7b Alpha - Copyright RotoWare 2015"), sleep(2)
print("\nBuild Date: 02/02/16 @ 08:50"), sleep(0.5)
print("\nThe time is", asctime(), "\n"), sleep(0.5)
res = 0
loggedout = 1
while 1:
    wintitle()
    sleep(0.2)
    if loggedout == 1:
        system('py.exe login.py')
    if not res == 1:
        user = open('currentuser.txt').read()
        main = input(user + "@PythonOS-Test> ")
        loggedout = 0
    if main == "list commands":
        print("list commands, help, help edit, edit, edit code, ver, logo, list programs,\nls/dir, magic 8 ball, clear/cls, apt-get install,\nopen, shutdown/exit, manucrash, reboot/restart, scandisk, reset, logout, createuser")
    elif main == "scandisk":
        workdir()
        sc = 0
        writefiles("safeshutdown.txt","1")
        screenclear()
        system('py.exe "scandisk.py"')
        chdir(owd1)
        writefiles("safeshutdown.txt","0")
        screenclear()
        system('color 07') 
    elif main == "help":
        workdir()
        chdir('Documents')
        system('k.exe pythonoshelp.txt')
        chdir(owd1)
    elif main == "help edit":
        workdir()
        chdir('Documents')
        system('k.exe khelp.txt')
        chdir(owd1)
        main = ""
    elif main == "edit code":
        workdir()
        system('start notepad++.exe "PythonOS.py"')
        chdir(owd1)
        main = ""
    elif "edit" in main:
        workdir()
        chdir('Documents')
        main = main.replace("edit", "")
        system('k.exe' + main)
        chdir('..')
        chdir(owd1)
    elif main == "ver":
        print("PythonOS Version 0.7 Alpha")
    elif main == "logo":
        logo()
    elif main == "list programs":
        workdir()
        system('type programlist.txt')
        print("\n")
        chdir(owd1)
    elif "dir" in main:
        system(main)
    elif main == "cd..":
        chdir("..")
    elif "cd " in main:
        main = main.replace ("cd ", "")
        try:
            chdir(main)
        except:
            print("Unable to change directory.")
    elif main == "magic 8 ball":
        owd1 = getcwd()
        chdir(owd)
        chdir('Documents')
        system('py.exe string.Input.Magic8Ball5.py')
        chdir(owd1)
    elif main == "clear" or main == "cls":
        screenclear()
    elif "apt-get install" in main:
        main = main.replace("apt-get install ", "")
        for x in range(1,101):
            print("Checking repositories...(" + str(x) + "%)", end='\r')
            sleep(0.02)
        print("")
        x = 0
        rand1 = randint(0,20)
        for x in range(1,101):
            print("Downloading", main, "from http://repositories.pythonos.net... (" + str(x) + "%)", end='\r')
            sleep(rand1/100)
        owd1 = getcwd()
        chdir(owd)
        file3 = open('programlist.txt', "a")
        file3.write(main), file3.write(", "), file3.close()  
        print("\nExtracting and setting up", main, end='\r')
        if rand1 < 10:
            sleep(rand1)
        else:
            sleep(rand1/10)
        print("Extracting and setting up", main,"complete.")
        chdir(owd1)
    elif "open" in main:
        workdir()
        main = main.replace("open ", "")
        if main in open("programlist.txt").read():
            print("Starting", main + ".")
            system("start " + main)
        if not main in open("programlist.txt").read():
            print("Program not installed. Run apt-get to install it.")
        chdir(owd1)
    elif main == "shutdown" or main == "exit":
        print("\nBroadcast from root@PythonOS-Test (pts/0) (" + asctime() + ")")
        print("\nThe system is going down NOW!")
        sleep(3)
        print("\nPowering off...")
        writefiles("safeshutdown.txt","1")
        writefiles("s.txt","1")
        sleep(0.5)
        ex()
    elif "manucrash" in main:
        sc = 0
        screenclear()
        crash()
    elif main == "reboot" or main == "restart":
        print("\nBroadcast from root@PythonOS-Test (pts/0) (" + asctime() + ")")
        print("\nThe system is going down for reboot NOW!")
        sleep(3)
        chdir(owd)
        writefiles("safeshutdown.txt","1")
        sleep(0.2)
        ex()
    elif main == "reset":
        sure = input("Are you sure you want to reset PythonOS? This will delete all text files in the PythonOS directory.\nConfirm by typing \"yes\" (w/o quotes): ")
        if sure == "yes":
            print("Resetting PythonOS, please wait.")
            remove("m8ballresults.txt"), remove("safeshutdown.txt"), remove("s.txt"), remove("m8ballusernames.txt"), remove("programlist.txt")
            print("PythonOS has been reset. System will reboot.")
            res = 1
            main = "reboot"
        else:
            print("Returning to prompt.")
    elif main == "logout":
        print("Logging out.")
        loggedout = 1
    elif main == "createuser":
        username = input("Enter a username. ")
        password = getpass(prompt='Enter a password. Note that input is hidden for security.')
        userfile = "Users/" + username + ".user"
        print("User created.")
        writefiles(userfile, password)
    else:
        print("Unknown command. Type \"list commands\" for a list of commands.")
print("Uh oh, you shouldn't see me. If you can, something is really badly wrong.")
print("Inspection of the code is required. System halted.")
sleep(400)
