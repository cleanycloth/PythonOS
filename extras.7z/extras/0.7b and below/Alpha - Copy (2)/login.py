from getpass import getpass
from os import path
if not path.exists("currentuser.txt"):
    file = open('currentuser.txt', "w")
    file.write(""), file.close()
while 1:
    user = input("login> ")
    if not path.exists("Users/" + user + ".user"):
        print("Invalid username, or the user has not been created.")
    if path.exists("Users/" + user + ".user"):
        passw = getpass(prompt='Password: ')
        passw1 = open('Users/' + user + '.user', "r")
        if not passw in passw1:
            print("Invalid password.")
        else:
            print("Logged in as " + user + ".")
            file = open('currentuser.txt', "w")
            file.write(user), file.close()
            exit()
    
