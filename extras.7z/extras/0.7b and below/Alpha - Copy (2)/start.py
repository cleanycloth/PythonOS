from os import system, path
from msvcrt import getch
def checkfile():
    if not path.exists("s.txt"):
        file = open('s.txt', "w")
        file.close()
while 1:
    go = system('py.exe "PythonOS.py"')
    checkfile()
    if "1" in open("s.txt").read():
        exit()
    if go == 2:
        print("\n\nUnable to start the virtual machine. Are you trying to run\nthe VM from a network location?\n\nPress any key to exit.")
        getch()
        exit()
