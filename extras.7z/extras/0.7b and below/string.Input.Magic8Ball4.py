#!/usr/bin/python
# The Magic 8 Ball, programmed by Aidan Rayner with optimization and some extra features by Nathan Barrall (new choice feature).
from random import choice                                                                                                                                                                                           # Imports random from choice
from time import sleep, asctime                                                                                                                                                                                     # Imports asctime and sleep from time
from os import path, remove, system                                                                                                                                                                                 # Imports path and remove from os
import platform                                                                                                                                                                                                     # Imports platform
from sys import exit                                                                                                                                                                                                # Imports exit
from getpass import getpass                                                                                                                                                                                         # Imports getpass
while 1:
    debug1 = 0
    if platform.system() == 'Windows':
        system('cls')
    else:
        system('clear')
    while 1:
        print("                                                        Magic 8 Ball v4.9 Stable")
        if not path.exists("m8ball.password"):                                                                                                                                                                      # Checks for the password file
            print("Password file not found. Debug mode will be unavailable.")
        if not path.exists("m8ballresults.txt"):                                                                                                                                                                    # Checks for the results file
            print("Generating new results file...")
            file = open('m8ballresults.txt', "w")                                                                                                                                                                   # If not found, it generates a new one.
            file.close()
        if not path.exists("m8ballusernames.txt"):                                                                                                                                                                  # Checks for the usernames file
            print("Generating new usernames file...")
            file2 = open('m8ballusernames.txt', "w")                                                                                                                                                                # If not found, it generates a new one.
            file2.close()
        print(), print("Hey there! Welcome to Magic 8 Ball - Python Edition!")
        a = input("What is your name? ")                                                                                                                                                                            # Asks for your name
        if a == "help":
            print("The purpose of the Magic 8 Ball - Python edition is to ask yes or no questions, in which you are given a random resposnse from a selection. \nYou may ask any question, though yes or no questions are preferred.")
        if a == "debug":                                                                                                                                                                                            # If debug is entered for the username field, it activates the debug mode.
            if not path.exists("m8ball.password"):
                print("Debug mode is unavailable because the password file is missing.")
                print("Replace the file, and restart.")
                break
            while 1:
                passw = getpass(prompt='Enter the password. ')                                                                                                                                                      # Asks for the password, while not showing the entered characters.
                passw1 = open('m8ball.password', "r")                                                                                                                                                               # Checks if the password is right
                if not passw in passw1:
                    print("Incorrect password. Try again.")
                else:
                    print("You have entered Magic 8 Ball debug mode.")
                    while 1:
                        debug1 = input("What would you like to do?\n1. Delete m8ballresults.txt file\n2. Delete m8ballusernames.txt file\n3. Delete both files\n4. Exit\n")                                         # Asks the user what they want to do.
                        if debug1 == "1":
                            print("Deleting results file..."), remove("m8ballresults.txt"), print("File deleted.")                                                                                                  # Deletes the results file if found
                            debug = 4
                            break
                        if debug1 == "2":
                            print("Deleting usernames file..."), remove("m8ballusernames.txt"), print("File deleted.")                                                                                              # Deletes the usernames file
                            break
                        if debug1 == "3":
                            print("Deleting usernames file..."), remove("m8ballusernames.txt"), print("Deleting results file..."), remove("m8ballresults.txt"), print("Files deleted.")                             # Deletes both files, if found.
                            break
                        if debug1 == "4":
                            break
                        else:
                            print("\nIncorrect input. Try again.\n")
                            sleep(2)
                            if platform.system() == 'Windows':
                                system('cls')
                            else:
                                system('clear')
                        break
                    break
        if debug1 == "1" or debug1 == "2" or debug1 == "3" or debug1 == "4":
            break
        if a in open('m8ballusernames.txt').read():
            print("Welcome back! I see you seek more advice.")
        else:
            qu = input("Welcome.\nYour name, question, and answer will be saved to a file in plaintext. \nDo you accept? [y/n] ")                                                                                   # Asks the user if they want to store their name in plaintext. This is required to use the program.
            if qu == "y":
                file3 = open('m8ballusernames.txt', "a")
                file3.write(a), file3.write(", "), file3.close()                                                                                                                                                    # Saves the username to a file
                print("Thank you. Your username has been saved.")
            else:
                print("You have not accepted the EULA. Restarting..")
                break
        if debug1 == "1" or debug1 == "2" or debug1 == "3" or debug1 == "4":
            break
        else:
            print()
            b = input("Ask me a question! Any question; I don't mind. : ")                                                                                                                                              # Asks the user for a question.
            if b == "What's the time?":
                print("The time and date is", asctime())
                break
            if b == "What OS am I running?":
                print("You are running ", platform.platform())
                osname = platform.platform()
                game = open("m8ballresults.txt", "a")
                game.write(a), game.write("\n"), game.write(b), game.write("\n"), game.write(osname), game.write("\n\n"), game.close(), print("\nYour data has been saved to m8ballresults.txt")
                break

            for x in range(1, 6):                                                                                                                                                                                       # For every number from 1 to 5:
                print("\rShaking... " + str(x) + "/5")                                                                                                                                                                    # Print "shaking" while increasing the number in that loop
                sleep(0.2)
            print()

            c = choice([                                                                                                                                                                                                # Chooses a result in the list, if the question was not either "Ping!", "What's the time?" or "What's my windows version?"
                "Try again later.",
                "Most certainly.",
                "The answer is something I cannot comprehend.",
                "java.lang.DoItLaterException(): Can't be bothered right now.",
                "No.",
                "Are you serious? No!",
                "Erm...okay. Sure.",
                "Yes.",
                "I don't know...",
                "Ask Neil, he might know.",
                "Something tells me that you shouldn't be asking me this...",
                "Quite possibly, though I cannot make any promises.",
                "Nah.",
                "Yeah!",
                "I fear the NSA is watching, so I won't answer this.",
                "Haha, no.",
                "Hm, maybe.",
                "Okay, yeah. Why not?",
                "Google is your friend.",
                "Yes, but don't tell Neil or Astrobot_, I don't want to give them any ideas!",
                "No, but don't tell Neil or Astrobot_, I don't want to give them any ideas!",
            ])
            if b == "Ping!":
                print("The Magic 8 Ball says: Pong!")
                game = open("m8ballresults.txt", "a")
                game.write(a), game.write("\n"), game.write(b), game.write("\n"), game.write("Pong!"), game.write("\n\n"), game.close(), print(), print("Your data has been saved to m8ballresults.txt")
                sleep(3)
                break
            else:
                print("The Magic 8 Ball says:", c)
                game = open("m8ballresults.txt", "a")
                game.write(a), game.write("\n"), game.write(b), game.write("\n"), game.write(c), game.write("\n\n"), game.close(), print("\nYour data has been saved to m8ballresults.txt")                             # Saves all data to a file.
                sleep(3)
                break
    print()
    quit1 = input("Would you like to restart? [y/n] ")
    if quit1 == "n":
        break
print("Thanks for playing! See you soon!")
sleep(3)
exit()
