import random
from time import sleep
from sys import exit
print("                                                              Magic 8 Ball v1.9")
print("Hello, and welcome to the Magic 8 Ball application.")
a = str(input("What is your name? "))
if a in open('m8ballusernames.txt').read():
    print("Welcome back. I see you seek more advice.")
else:
    qu = input("Welcome, new user. \nYour name, question, and answer will be saved to a file. \nDo you accept? [y/n] ")
    if qu == "y":
        print("Thank you. Your details will be saved at the end.")
    else:
        print("You have not accepted the EULA. Closing the application.")
        exit()
b = str(input("Ask me a question. Any question, I don't mind. "))
sleep(1)
print("Shaking... 1/4")
sleep(1)
print("Shaking... 2/4")
sleep(1)
print("Shaking... 3/4")
sleep(1)
print("Shaking... 4/4")
sleep(1)
print()
c = random.randint(1,8)
if c == 1:
    ball1 = "Try again later."
    print(ball1)
    game = open("m8ballresults.csv", "a")
    game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(ball1) & game.write("\n") & game.write("\n")
    game.close()
elif c == 2:
    ball2 = "Most certainly."
    print(ball2)
    game = open("m8ballresults.csv", "a")
    game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(ball2) & game.write("\n") & game.write("\n")
    game.close()
elif c == 3:
    ball3 = "The answer is something I cannot comprehend."
    print(ball3)
    game = open("m8ballresults.csv", "a")
    game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(ball3) & game.write("\n") & game.write("\n")
    game.close()
elif c == 4:
    ball4 = "java.lang.DoItLater exception(): Can't be bothered right now."
    print(ball4)
    game = open("m8ballresults.csv", "a")
    game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(ball4) & game.write("\n") & game.write("\n")
    game.close()
elif c == 5:
    ball5 = "No."
    print(ball5)
    game = open("m8ballresults.csv", "a")
    game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(ball5) & game.write("\n") & game.write("\n")
    game.close()
elif c == 6:
    ball6 = "Are you serious? No!"
    print(ball6)
    game = open("m8ballresults.csv", "a")
    game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(ball6) & game.write("\n") & game.write("\n")
    game.close()
elif c == 7:
    ball7 = "Erm...okay. Sure."
    print(ball7)
    game = open("m8ballresults.csv", "a")
    game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(ball7) & game.write("\n") & game.write("\n")
    game.close()
elif c == 8:
    ball8 = "Yes."
    print(ball8)
    game = open("m8ballresults.csv", "a")
    game.write(a) & game.write("\n") & game.write(b) & game.write("\n") & game.write(ball8) & game.write("\n") & game.write("\n")
    game.close()
print()
print("File saved as m8ballresults.csv")
sleep(3)
