hello = dict()
for x in range(1,13):
    hello[1] = "hi"
    hello[2] = "bonjour"
print(hello[1])
print(hello[2])
