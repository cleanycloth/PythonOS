#The Magic 8 Ball, programmed by Aidan Rayner with optimization and some extra features by Nathan Barrall. This only works on Windows!
from random import choice                                                                                                                                                   #Imports random from choice
from time import sleep, asctime                                                                                                                                             #Imports asctime and sleep from time
from os import path, remove                                                                                                                                                 #Imports path and remove from os
from platform import system, release
plat = system()
if plat == "Windows":
    from sys import exit, getwindowsversion
else:
    from sys import exit
from getpass import getpass                                                                                                                                                 #Imports getpass
print("                                                        Magic 8 Ball v3.3 Stable")
if not path.exists("m8ball.password"):                                                                                                                                      #Checks for the password file
    print("Password file not found. Debug mode will be unavailable.")
if not path.exists("m8ballresults.txt"):                                                                                                                                    #Checks for the results file
    print("Generating new results file...")
    file = open('m8ballresults.txt', "w")                                                                                                                                   #If not found, it generates a new one.
    file.close()
if not path.exists("m8ballusernames.txt"):                                                                                                                                  #Checks for the usernames file
    print("Generating new usernames file...")
    file2 = open('m8ballusernames.txt', "w")                                                                                                                                #If not found, it generates a new one.
    file2.close()
print(), print("Hello, and welcome to the Magic 8 Ball application. My name is Dave.")
a = input("What is your name? ")                                                                                                                                            #Asks for your name

if a == "debug":                                                                                                                                                            #If debug is entered for the username field, it activates the debug mode.
    passw = getpass(prompt='Enter the password. ')                                                                                                                          #Asks for the password, while not showing the entered characters.
    passw1 = open('m8ball.password', "r")                                                                                                                                   #Checks if the password is right
    if not passw in passw1:
        print("Incorrect password. Restart the program and try again.")
        exit()
    print("Welcome to the Magic 8 Ball debug mode.")
    debug1 = input("What would you like to do?\n1. Delete m8ballresults.txt file\n2. Delete m8ballusernames.txt file\n3. Delete both files\n")                              #Asks the user what they want to do.
    if debug1 == "1":
        if path.exists("m8ballresults.txt"):
            print("Deleting results file..."), remove("m8ballresults.txt"), print("File deleted.")                                                                          #Deletes the results file if found
            exit()
        if not path.exists("m8ballresults.txt"):
            print("File not found. Please restart.")
            exit()
    if debug1 == "2":
        if path.exists("m8ballusernames.txt"):
            print("Deleting usernames file..."), remove("m8ballusernames.txt"), print("File deleted.")                                                                      #Deletes the usernames file
            exit()
        if not path.exists("m8ballusernames.txt"):
            print("File not found. Please restart.")
            exit()
    if debug1 == "3":
        print("Deleting usernames file..."), remove("m8ballusernames.txt"), print("Deleting results file..."), remove("m8ballresults.txt"), print("Files deleted.")         #Deletes both files, if found.
        exit()
    else:
        print("Incorrect input. Restart the program and try again.")
        exit()

if a in open('m8ballusernames.txt').read(): 
    print("Welcome back. I see you seek more advice.")
else:
    qu = input("Welcome, user.\nYour name, question, and answer will be saved to a file in plaintext. \nDo you accept? [y/n] ")                                             #Asks the user if they want to store their name in plaintext. This is required to use the program.
    if qu == "y":
        file3 = open('m8ballusernames.txt', "w")
        file3.write(a), file3.write("\n"), file3.close()                                                                                                                    #Saves the username to a file
        print("Thank you. Your username has been saved.")
    elif qu == "n":
        print("You have not accepted the EULA. Closing the application.")
        exit()
        sleep(3)
print()
b = input("Ask me a question! Any question; I don't mind. : ")                                                                                                              #Asks the user for a question.
if b == "What's the time?":
    print("The time and date is", asctime())
    sleep(5)
    exit()
if b == "What version of Windows am I running?":
    if plat == "Windows":
        print("You are running Windows", release())                                                                                                                             #Prints the Windows version
        print("More detailed information:", getwindowsversion())
        sleep(5)
        exit()
    else:
        print("You're not running Windows, silly!")
        sleep(2)
        exit()
for x in range(1,5):                                                                                                                                                        #For every number from 1 to 4:
    print("Shaking... "+str(x)+"/4")                                                                                                                                        #Print "shaking" while increasing the number in that loop
    sleep(0.5)
print()

if b == "Ping!":
    pong = "Pong!"
    print("The Magic 8 Ball says: Pong!")
    game = open("m8ballresults.txt", "a")
    game.write(a), game.write("\n"), game.write(b), game.write("\n"), game.write(pong), game.write("\n"), game.write("\n"), game.close()                                    #Saves all data to a file
    print(), print("Your data has been saved to m8ballresults.txt")
    sleep(3)
    exit()

c = choice([                                                                                                                                                                #Chooses a result in the list, if the question was not either "Ping!", "What's the time?" or "What's my windows version?"
    "Try again later.",
    "Most certainly.",
    "The answer is something I cannot comprehend.",
    "java.lang.DoItLaterException(): Can't be bothered right now.",
    "No.",
    "Are you serious? No!",
    "Erm...okay. Sure.",
    "Yes.",
    "I don't know...",
    "Ask Neil, he might know.",
    "Something tells me that you shouldn't be asking me this...",
    "Quite possibly, though I cannot make any promises.",
    "Nah.",
    "Yeah!",
    "I fear the NSA is watching, so I won't answer this.",
    "Haha, no.",
    "Hm, maybe.",
    "Okay, yeah. Why not?",
    "Google is your friend.",
    "Yes, but don't tell Neil or Astrobot_, I don't want to give them any ideas!",
    "No, but don't tell Neil or Astrobot_, I don't want to give them any ideas!",
])
print("The Magic 8 Ball says:", c)
game = open("m8ballresults.txt", "a")
game.write(a), game.write("\n"), game.write(b), game.write("\n"), game.write(c), game.write("\n"), game.write("\n"), game.close(), print(), print("\n\n\n\n\nYour data has been saved to m8ballresults.txt")        #Saves all data to a file.
sleep(3)
