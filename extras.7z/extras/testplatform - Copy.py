##from configparser import ConfigParser
##from os import system, path
##from time import sleep
###system('playsound.bat')
##config = ConfigParser()
##while 1:
##    input("")
##    if not path.exists('test.ini'):
##        file = open('test.ini','w')
##        file.close()
##    config.read('test.ini')
##    print(config.sections())
##sleep(500)


from time import sleep
import vlc
from os import system

##text = "This is a long string of text. It is a wonderful, long string of text."
##
##for x in range(len(text)):
##    print(text[0:x+1], end='\r')
##    sleep(0.07)
##sleep(2)
vlc.MediaPlayer("spotted.nsf").play()
print(" "*80)
print("\n\n\n\n\n")
print("|".rjust(37))
print("|".rjust(37))
print("|".rjust(37))
print("|".rjust(37))
print("O".rjust(37))
sleep(0.8)
print("You've been spotted.".rjust(48))
sleep(0.8)
system('cls')
print("This is where the thing goes.")
input("Test input: ")
